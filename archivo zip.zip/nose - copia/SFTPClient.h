#pragma once
#include <string>

bool downloadCSVFromSFTP(const std::string& remotePath, const std::string& localPath);
